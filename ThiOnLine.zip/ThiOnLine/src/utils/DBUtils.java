package utils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import beans.TaiKhoan;
import beans.ThongTinTK;


public class DBUtils {
	
	/*public static TaiKhoan findUser(
            String TenTK, String MatKhau) throws SQLException {
 
        String sql = "select * form TaiKhoan wher MatKhau = " + MatKhau + "And TenTK = "
        		+ TenTK;
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, TenTK);
        pstm.setString(2, MatKhau);
        ResultSet rs = pstm.executeQuery();
 
        if (rs.next()) {
            TaiKhoan user = new TaiKhoan();
            user.setTenTK(TenTK);
            user.setMatKhau(MatKhau);
            return user;
        }
        return null;
    }
 
    public static User findUser(Connection conn, String TenTK) throws SQLException {
 
        String sql = "Select a.User_Name, a.MatKhau, a.Gender from User_Account a "//
                + " where a.User_Name = ? ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, TenTK);
 
        ResultSet rs = pstm.executeQuery();
 
        if (rs.next()) {
            String MatKhau = rs.getString("MatKhau");
            String gender = rs.getString("Gender");
            User user = new User();
            user.setTenTK(TenTK);
            user.setMatKhau(MatKhau);
            user.setGender(gender);
            return user;
        }
        return null;
    }
 */
	 public static List<ThongTinTK> LayDSNguoiDung(Connection conn) throws SQLException {
	        String sql = "execute LayDanhSachHocSinh"; 
	        PreparedStatement pstm = conn.prepareStatement(sql); 
	        ResultSet rs = pstm.executeQuery();
	        List<ThongTinTK> list = new ArrayList<ThongTinTK>();
	        while (rs.next()) {
	            String tentk = rs.getString("TenTK");
	            String name = rs.getString("TenNguoiDung");
	            Date ngaysinh = rs.getDate("NgaySinh");
	            int soluonglop = rs.getInt("SoLuong");
	            ThongTinTK tk = new ThongTinTK();
	            tk.setTenTK(tentk);
	            tk.setTenNguoiDung(name);
	            tk.setNgaySinh(ngaysinh);
	            tk.setSoLuongLopHoc(soluonglop);
	            list.add(tk);
	        }
	        return list;
	    }
 
    /*
    public static Product findProduct(Connection conn, String code) throws SQLException {
        String sql = "Select a.Code, a.Name, a.Price from Product a where a.Code=?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, code);
 
        ResultSet rs = pstm.executeQuery();
 
        while (rs.next()) {
            String name = rs.getString("Name");
            float price = rs.getFloat("Price");
            Product product = new Product(code, name, price);
            return product;
        }
        return null;
    }
 
    public static void updateProduct(Connection conn, Product product) throws SQLException {
        String sql = "Update Product set Name =?, Price=? where Code=? ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, product.getName());
        pstm.setFloat(2, product.getPrice());
        pstm.setString(3, product.getCode());
        pstm.executeUpdate();
    }
 
    public static void insertProduct(Connection conn, Product product) throws SQLException {
        String sql = "Insert into Product(Code, Name,Price) values (?,?,?)";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, product.getCode());
        pstm.setString(2, product.getName());
        pstm.setFloat(3, product.getPrice());
 
        pstm.executeUpdate();
    }
 
    public static void deleteProduct(Connection conn, String code) throws SQLException {
        String sql = "Delete From Product where Code= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, code);
 
        pstm.executeUpdate();
    }*/
}
